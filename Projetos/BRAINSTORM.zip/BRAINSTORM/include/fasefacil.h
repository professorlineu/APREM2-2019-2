void fasefacil();
