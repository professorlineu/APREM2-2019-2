#include <iostream>
#include <locale.h>
#include <cstdlib>
#include <time.h>
#include<windows.h>
#include<stdlib.h>
using namespace std;

// defini��o da fun��o
int NIVEL2fase2 (void)
{
    int iAleatorio[6];//n�meros aleat�rios
    int iresposta[6];//resporta do jogador
    int i=0;//contagem e armazenamento
    int t=0;//tempo
    int iacertos=0;//contagem de acertos
    int idesempenhoN2F2 =0;

    setlocale(LC_ALL,"");
    system("color 0");
    /* CORPO DO JOGO */
    srand(time(NULL));//N�O REPETIR N�
    cout << "\n\nVoc� escolheu escolheu a fase 2: \n Aparecer�o 6 n�meros sorteados entre 1 e 30, prepare-se:\n";
    Sleep(7000);
    system("cls");
    for (i=0; i<6; i++)
    {
        iAleatorio[i] = rand() % 30 + 1;
    }
    t=12;
//TEMPORIZADOR e vizualiza��o dos n�meros
    while (t>0)
    {

        system ("cls");
        cout << "Decore os n�meros em "<< t << "\n\n\n";
        t--;

        for (i=0; i<6; i++)
        {

            cout<<iAleatorio[i]<<"\t";
        }
        Sleep (1000);

    }
    system ("cls");
    cout << "informe os n�meros digitados.";
    i=0;

    for (i=0; i<6; i++)
    {
        cout<<"\n"<<i+1<<" n�mero: ";

        cin>> iresposta[i];
        if (iresposta[i]==iAleatorio[i])
        {
            iacertos++;
        }
    }


    if (iacertos==6)
    {
        idesempenhoN2F2++;
        cout << "PARAB�NS, AT� A PR�XIMA FASE!";
        cout << "\n\n Os n�meros sorteados s�o: ";
        for (i=0; i<6; i++)
        {

            cout<<iAleatorio[i]<<"\t";
        }
    }
    else
    {
        cout << "PARECE QUE SUA MEM�RIA N�O EST� T�O BOA, MAS CONTINUE TENTANDO...";
        cout << "\n\n Os n�meros sorteados s�o: ";
        for (i=0; i<6; i++)
        {

            cout<<iAleatorio[i]<<"\t";
        }
    }
    return (idesempenhoN2F2);
}
