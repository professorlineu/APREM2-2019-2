#include "fasefacil.h"
#include "fasemedia.h"
#include <iostream>
#include <locale.h>
#include <cstdlib>
#include <windows.h>
#include <conio.h>
#include <time.h>
#include "inicio.h"
#include "carreg.h"

using namespace std;


void fasefacil()
    {
        int iChoice=0;
        int iResposta = 0;
        int iPontuacaoF = 0;
        int iEscolha = 0;

        cout << "\n\tVoc� est� na fase f�cil."
             << "\n\n\tAperte 0 para sair.";

        Sleep(1000);

        system("cls");

        cout << "\n\n\t ---- N�VEL 1 -->"
             << "\n\n\t Descubra a s�rie a partir da frase: "
             << "\n\n\t 'O inverno est� chegando...' ";

        cout << "\n\n\t 1 - The Walking Dead"
             << "\n\t 2 - Game of Thrones"
             << "\n\t 3 - Vikings";

        cout << "\n\t Resposta: ";
        cin  >> iResposta;

        Sleep (1000);

        if (iResposta == 2)
        {
        cout << "\n\tResposta Correta!";

        iPontuacaoF = iPontuacaoF + 100;
        }
        else if (iResposta == 0)
        {
        system("cls");
        carreg();
        inicio();
        }

        else
        {
        cout << "\n\tResposta Errada.";

        iPontuacaoF= iPontuacaoF - 20;

        }

        Sleep(1000);

        system("cls");

        cout << "\n\n\t ---- N�VEL 2 -->"
             << "\n\n\t Descubra a s�rie a partir da palavra chave: "
             << "\n\n\t 'Valhalla' ";

        cout << "\n\n\t 1 - Altered Carbon"
             << "\n\t 2 - Sons of Anarchy"
             << "\n\t 3 - Vikings";

        cout << "\n\t Resposta: ";
        cin  >> iResposta;

        Sleep (1000);

        if (iResposta == 3)
        {
        cout << "\n\t Resposta Correta!";

        iPontuacaoF = iPontuacaoF + 100;
        }
        else if (iResposta == 0)
        {
        system("cls");
        carreg();
        inicio();
        }

        else
        {
        cout << "\n\t Resposta Errada.";

        iPontuacaoF = iPontuacaoF - 20;

        }

        Sleep (1000);

        system("cls");

        cout << "\n\n\t ---- N�VEL 3 -->"
             << "\n\n\t Descubra a pessoa: "
             << "\n\n\t 'miei dels do ceu gent, olh iss, suj' ";

        cout << "\n\n\t 1 - Gusteau"
             << "\n\t 2 - Jacquin"
             << "\n\t 3 - Paola Carosella";

        cout << "\n\t Resposta: ";
        cin  >> iResposta;

        Sleep (1000);

        if (iResposta == 2)
        {
        cout << "\n\t Resposta Correta!";

        iPontuacaoF = iPontuacaoF + 100;
        }
        else if (iResposta == 0)
        {
        system("cls");
        carreg();
        inicio();
        }

        else
        {
        cout << "\n\t Resposta Errada.";

        iPontuacaoF = iPontuacaoF - 20;

        }

        Sleep (1000);

        system("cls");

        cout << "\n\n\t ---- N�VEL 4 -->"
             << "\n\n\t Descubra a s�rie: "
             << "\n\n\t 'Berlim, Nair�bi, Helsinki' ";

        cout << "\n\n\t 1 - DARK "
             << "\n\t 2 - A lista Negra"
             << "\n\t 3 - La Casa de Papel";

        cout << "\n\t Resposta: ";
        cin  >> iResposta;

        Sleep (1000);

        if (iResposta == 3)
        {
        cout << "\n\t Resposta Correta!";

        iPontuacaoF = iPontuacaoF + 100;
        }
        else if (iResposta == 0)
        {
        system("cls");
        carreg();
        inicio();
        }

        else
        {
        cout << "\n\t Resposta Errada.";

        iPontuacaoF = iPontuacaoF - 20;

        }

        Sleep (1000);

        system("cls");

        cout << "\n\n\t ---- N�VEL 5 -->"
             << "\n\n\t Descubra o filme: "
             << "\n\n\t 'I'll be back.' ";

        cout << "\n\n\t 1 - Back to the Future"
             << "\n\t 2 - Exterminador do Futuro"
             << "\n\t 3 - Mercen�rios";

        cout << "\n\t Resposta: ";
        cin  >> iResposta;

        Sleep (1000);

        if (iResposta == 2)
        {
        cout << "\n\t Resposta Correta!";

        iPontuacaoF = iPontuacaoF + 100;
        }
        else if (iResposta == 0)
        {
        system("cls");
        carreg();
        inicio();
        }

        else
        {
        cout << "\n\t Resposta Errada.";

        iPontuacaoF = iPontuacaoF - 20;

        }


        Sleep (2000);

        system("cls");

        cout << "\n\n\tP";
        Sleep(100);

        cout << "on";
        Sleep(100);

        cout << "tu";
        Sleep(100);

        cout << "a";
        Sleep(100);

        cout << "��";
        Sleep(100);

        cout << "o:";
        Sleep(100);

        cout << " " << iPontuacaoF << " pontos.";

        if (iPontuacaoF == 500)
        {
        cout << "\n\n\tVoc� acertou 5/5."; Sleep(400);
        cout << "\n\tSeu conhecimento da cultura pop � �timo!";
        }
        else if (iPontuacaoF == 380)
        {
        cout << "\n\n\tVoc� acertou 4/5."; Sleep(400);
        cout << "\n\tFoi por pouco, talvez voc� tenha deixado de assistir um filme.";
        }
        else if (iPontuacaoF == 260)
        {
        cout << "\n\n\tVoc� acertou 3/5."; Sleep(400);
        cout << "\n\tSer� que foi aquela s�rie que voc� disse que n�o gostava?";
        }
        else if (iPontuacaoF == 140)
        {
        cout << "\n\n\tVoc� acertou 2/5."; Sleep(400);
        cout << "\n\t� como dizem... 1 � pouco, 2 � bom, 3 � demais.";
        }
        else if (iPontuacaoF == 20)
        {
        cout << "\n\n\tVoc� acertou 1/5."; Sleep(400);
        cout << "\n\tVou fingir que voc� estuda muito e n�o tem tempo de assistir muitos filmes, ok?";
        }
        else
        {
        cout << "\n\n\tVoc� acertou 0/5."; Sleep(400);
        cout << "\n\tSer� que estava t�o dif�cil assim?"; Sleep(400);
        cout << " vou dar uma olhada nos meus c�digos...";
        }

        Sleep(1000);

        cout << "\n\n\tContinuar? Sim(1) N�o(2)\n\n\t           ";
        cin  >> iEscolha;

        if (iEscolha == 1)
        {
        carreg();
        fasemedia();
        }
        else
        {
        system("cls");
        inicio();
        }

        }


