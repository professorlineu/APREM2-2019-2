#include "inicio.h"
#include <iostream>
#include <locale.h>
#include <cstdlib>
#include <windows.h>
#include <conio.h>
#include <time.h>
#include "carreg.h"
#include "fasefacil.h"
#include "sair.h"
#include "continuar.h"
#include "creditos.h"

using namespace std;

void inicio()

    {

    int i=0;
    int iEscolha=0;

    system("cls");

    cout << "\n\n\t-";

    for (i=0; i<4; i++)
    {
    cout << "----";
    Sleep(50);
    }

    cout << "\n\t|               |";
    Sleep(50);

    cout << "\n\t|  B";
    Sleep(50);

    cout << "RA";
    Sleep(50);

    cout << "IN";
    Sleep(50);

    cout << "S";
    Sleep(50);

    cout << "T";
    Sleep(50);

    cout << "O";
    Sleep(50);

    cout << "RM";
    Sleep(50);

    cout << "! ";
    Sleep(50);

    cout << " |";
    Sleep(50);

    cout << "\n\t|               |\n\t-";
    Sleep(50);


    for (i=0; i<4; i++)
    {
    cout << "----";
    Sleep(50);
    }

    cout << "\n\n\t-";

    for (i=0; i<4; i++)
    {
    cout << "----";
    Sleep(50);
    }

    cout << "\n\t|               |";
    Sleep(50);

    cout << "\n\t|   1  JOGAR    |";
    Sleep(50);

    cout << "\n\t|  2 CR�DITOS   |";
    Sleep(50);

    cout << "\n\t|    0 SAIR     |";
    Sleep(50);

    cout << "\n\t|               |";
    Sleep(50);

    cout << "\n\t-";

    for (i=0; i<4; i++)
    {
    cout << "----";
    Sleep(50);
    }

    cout << "\n\t        ";
    cin  >> iEscolha;

        if (iEscolha == 1)
        {
        system("cls");
        carreg();
        continuar();
        }
        else if (iEscolha == 2)
        {
        system("cls");
        creditos();
        }
        else if (iEscolha == 0)
        {
        system("cls");
        sair();
        }
        else if (iEscolha != 1,2,0)
        {
        cout << "\n\n\t  Op��o Inv�lida.";
        Sleep(1000);
        system("cls");
        inicio();
        }

    }

