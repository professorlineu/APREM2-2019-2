#include <iostream>
using namespace std;

// prot�tipo da fun��o
int NIVEL3fase2 (void);
