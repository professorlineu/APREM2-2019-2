void fasedificil();
