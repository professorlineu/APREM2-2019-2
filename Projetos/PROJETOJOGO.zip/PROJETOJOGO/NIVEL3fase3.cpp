/*DESENVOLVENDO NIVEL 3 FASE 3*/
//BIBLIOTECA
#include <iostream>
#include <locale.h>
#include <cstdlib>
#include <time.h>
#include<windows.h>
#include<stdlib.h>
using namespace std;

void SetColor(int ForgC);

// defini��o da fun��o
int NIVEL3fase3 (void)
{

    int iCor [5];
    int iAleatorio[5];//n�meros aleat�rios
    int iresposta2[5];
    int iresposta[5];//resporta do jogador
    int i=0;//contagem e armazenamento
    int t=0;//tempo
    int iacertos=0;//contagem de acertos
    int iacertoscores=0;
    int iNCor = 1;
    int idesempenhoN3F3 =0;

    setlocale(LC_ALL,"");
    system("color 0");
    /* CORPO DO JOGO */
    srand(time(NULL));//N�O REPETIR N�
    cout << "\n\nVoc� escolheu escolheu a fase 3: \n Aparecer�o 5 n�meros sorteados coloridos entre 1 e 30, prepare-se:\n";
    Sleep(7000);
    system("cls");

    for (i=0; i<5; i++)
    {
        iCor[i] = rand() % 8 + 1 ;

    }
    for (i=0; i<5; i++)
    {

        iAleatorio[i] = rand() % 30 + 1;
    }

    t=8;
//TEMPORIZADOR e vizualiza��o dos n�meros
    while (t>0)
    {
        SetColor(15);
        system ("cls");
        cout << "Decore os n�meros e as cores em "<< t << "\n\n\n";
        t--;

        for (i=0; i<5; i++)
        {
            SetColor(iCor[i]);
            cout<<iAleatorio[i]<<"\t";
        }
        Sleep (1000);

    }
    system ("cls");
    SetColor(15);
    cout << "informe os n�meros digitados e suas respectivas cores.\n";

    while (iNCor < 9)
    {
        SetColor(iNCor);
        cout << "\t\t\t\t\t\tCores " << iNCor << endl;
        iNCor++;
    }

    i=0;

    for (i=0; i<5; i++)
    {
        SetColor(15);
        cout<<"\n"<<i+1<<" � n�mero: ";
        cin>> iresposta[i];
        cout<<"\n"<<i+1<<" cor: ";
        cin>> iresposta2[i];
        if (iresposta[i]==iAleatorio[i])
        {
            iacertos++;
        }
        if (iresposta2[i]==iCor[i])
        {
            iacertoscores++;
        }
    }


    if (iacertos==5 && iacertoscores==5)
    {
        idesempenhoN3F3++;
        cout << "PARAB�NS, AT� A PR�XIMA FASE!";
        cout << "\n\n Os n�meros e as cores sorteadas s�o: ";
        for (i=0; i<5; i++)
        {
            SetColor(iCor[i]);
            cout<<iAleatorio[i]<<"\t";
            SetColor(15);
        }
    }
    else
    {
        SetColor(15);
        cout << "PARECE QUE SUA MEM�RIA N�O EST� T�O BOA, MAS CONTINUE TENTANDO...";
        cout << "\n\n Os n�meros e cores sorteadas s�o: ";
        for (i=0; i<5; i++)
        {
            SetColor(iCor[i]);
            cout<<iAleatorio[i]<<"\t";
            SetColor(15);
        }
    }
    return (idesempenhoN3F3);
}
/*void SetColor(int ForgC)
{

    WORD wColor;
    //We will need this handle to get the current background attribute
    HANDLE hStdOut = GetStdHandle(STD_OUTPUT_HANDLE);
    CONSOLE_SCREEN_BUFFER_INFO csbi;

    //We use csbi for the wAttributes word.
    if(GetConsoleScreenBufferInfo(hStdOut, &csbi))
    {
        //Mask out all but the background attribute, and add in the forgournd color
        wColor = (csbi.wAttributes & 0xF0) + (ForgC & 0x0F);
        SetConsoleTextAttribute(hStdOut, wColor);
    }
    return;
}

/*
Color	        Value
BLACK	        0
BLUE	        1
GREEN	        2
CYAN	        3
RED	            4
MAGENTA	        5
BROWN	        6
LIGHTGRAY	    7
DARKGRAY	    8
LIGHTBLUE	    9
LIGHTGREEN	    10
LIGHTCYAN	    11
LIGHTRED	    12
LIGHTMAGENTA	13
YELLOW	        14
WHITE	        15
*/
