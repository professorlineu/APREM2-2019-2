void easy ();
