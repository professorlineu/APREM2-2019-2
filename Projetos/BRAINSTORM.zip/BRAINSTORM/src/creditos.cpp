#include "creditos.h"
#include "inicio.h"
#include <iostream>
#include <locale.h>
#include <cstdlib>
#include <windows.h>
#include <conio.h>
#include <time.h>
#include "carreg.h"

using namespace std;

void creditos()
{

    Sleep(1000);

cout << "\n\n\tEs";
Sleep(100);

cout << "te";
Sleep(100);

cout << " ";
Sleep(100);

cout << "�";
Sleep(100);

cout << " ";
Sleep(100);

cout << "um";
Sleep(100);

cout << " j";
Sleep(100);

cout << "o";
Sleep(100);

cout << "go";
Sleep(100);

cout << " ";
Sleep(100);

cout << "f";
Sleep(100);

cout << "ei";
Sleep(100);

cout << "t";
Sleep(100);

cout << "o ";
Sleep(100);

cout << "p";
Sleep(100);

cout << "o";
Sleep(100);

cout << "r:";
Sleep(300);

cout << "\n\n\t- Vitor Kenzo Kikuchi";
Sleep(500);

cout << "\n\n\t- Ramon Oliveira Macedo";
Sleep(500);

cout << "\n\n\t- Thomas Nicolas Taquetto";
Sleep(1000);

cout << "\n\n\n\tAperte qualquer tecla...";
getch();

carreg();
inicio();

}
