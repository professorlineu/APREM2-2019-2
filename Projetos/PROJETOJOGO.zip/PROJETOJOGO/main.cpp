/**********************************************************
- Autor:     YASMIN SENA E RENAN SALVAZZINI
- Descri��o: JOGO DA MEM�RIA
**********************************************************/
//BIBLIOTECA
#include <iostream>
#include "NIVEL1fase1.h"
#include "NIVEL1fase2.h"
#include "NIVEL1fase3.h"
#include "NIVEL2fase1.h"
#include "NIVEL2fase2.h"
#include "NIVEL2fase3.h"
#include "NIVEL3fase1.h"
#include "NIVEL3fase2.h"
#include "NIVEL3fase3.h"
#include <locale.h>
#include <cstdlib>
#include <time.h>
#include<windows.h>
#include<stdlib.h>

//#include <stdio.h>

//#include <conio.h>

//fazer a variavel para todos
using namespace std;
void SetColor(int ForgC);

int main()
{
    //DECLARA��O DE VARIAVEIS
    int iNIVEL=0;
    int iFASE=0;
    int ipontuacaoN1F1=0;
    int ipontuacaoN1F2=0;
    int ipontuacaoN1F3=0;
    int ipontuacaoN2F1=0;
    int ipontuacaoN2F2=0;
    int ipontuacaoN2F3=0;
    int ipontuacaoN3F1=0;
    int ipontuacaoN3F2=0;
    int ipontuacaoN3F3=0;
    setlocale(LC_ALL,"");
    system("color 0");
//INTRODU��O
    SetColor(13);
    cout << "\n\n\n\n\n\n\n\n\n\n\n O JOGO A SEGUIR DESAFIA SUA MEM�RIA, VEN�A SE PUDER...";
    Sleep(5000); // 3000 milesegundos = 3 segundos
    SetColor(15);
    while (iNIVEL != 4)
    {


        system("cls");
//MENU DOS N�VEIS
        cout << "----------------------------------------\n\n";
        Sleep(0250);
        cout << "1 - N�VEL 1      (04 N�MEROS)\n\n";
        Sleep(0250);
        cout << "2 - N�VEL 2      (06 N�MEROS)\n\n";
        Sleep(0250);
        cout << "3 - N�VEL 3      (05 N�MEROS COLORIDOS)\n\n";
        Sleep(0250);
        cout << "4 - Sair\n\n";
        Sleep(0250);
        cout << "5 - DESEMPENHO\n\n";
        Sleep(0250);
        cout << "----------------------------------------\n\n";

        cout << "Escolha seu N�VEL: ";
        cin >> iNIVEL;
        system("cls");
        //DECLARA��O DE FASES PARA CADA NIVEL
        switch(iNIVEL)
        {
        case 1:

            cout << "Voc� escolheu escolheu o n�vel 1, escolha sua FASE:\n";
            //MENU FASE NIVEL 1 E INTODUZIR O JOGO DENTRO DO CASO
            cout << "----------------------------------------\n\n";
            cout << "1 - FASE 1      (12 SEGUNDOS)\n\n";
            cout << "2 - FASE 2      (10 SEGUNDOS)\n\n";
            cout << "3 - FASE 3      (08 SEGUNDOS)\n\n";
            cout << "4 - Retornar ao menu principal\n\n";
            cout << "----------------------------------------\n\n";

            cout << "Escolha sua FASE: ";
            cin >> iFASE;
            system("cls");

            switch (iFASE)
            {

            case 1:
                Sleep(0500);
                system("cls");
                ipontuacaoN1F1 += NIVEL1fase1();
                Sleep(6000);
                system("cls");
                break;
            //return main();

            case 2:
                Sleep(0500);
                system("cls");
                ipontuacaoN1F2 += NIVEL1fase2();
                Sleep(6000);
                system("cls");
                break;
            // return main ();
            case 3:
                Sleep(0500);
                system("cls");
                ipontuacaoN1F3 += NIVEL1fase3();
                Sleep(6000);
                system("cls");
                break;
            //return main ();
            case 4:
                //cout << "Voc� saiu do jogo.";
                break;
            default:
                cout << "Valor Inv�lido!\n";
                Sleep(6000);
                system("cls");
                break;
                //return main ();
            }

            break;
        case 2:
            cout << "Voc� escolheu escolheu o n�vel 2, escolha sua FASE:\n";
            //MENU FASE NIVEL 2 E INTODUZIR O JOGO DENTRO DO CASO
            cout << "----------------------------------------\n\n";
            cout << "1 - FASE 1      (14 SEGUNDOS)\n\n";
            cout << "2 - FASE 2      (12 SEGUNDOS)\n\n";
            cout << "3 - FASE 3      (10 SEGUNDOS)\n\n";
            cout << "4 - Retornar ao menu principal\n\n";
            cout << "----------------------------------------\n\n";

            cout << "Escolha sua FASE: ";
            cin >> iFASE;
            system("cls");
            switch (iFASE)
            {
            case 1:
                Sleep(0500);
                system("cls");
                ipontuacaoN2F1 += NIVEL2fase1();
                Sleep(6000);
                system("cls");
                break;
            //return main ();
            case 2:
                Sleep(0500);
                system("cls");
                ipontuacaoN2F2 += NIVEL2fase2();
                Sleep(6000);
                system("cls");
                break;
            //return main ();
            case 3:
                Sleep(0500);
                system("cls");
                ipontuacaoN2F3 += NIVEL2fase3();
                Sleep(6000);
                system("cls");
                break;
            //return main ();
            case 4:
                cout << "Voc� saiu do jogo.";
                break;

            default:
                cout << "Valor Inv�lido!\n";
                Sleep(6000);
                system("cls");
                break;
                //return main ();
            }
            break;
        case 3:
            cout << "Voc� escolheu escolheu o n�vel 3, escolha sua FASE:\n";
            //MENU FASE NIVEL 3 E INTODUZIR O JOGO DENTRO DO CASO
            cout << "----------------------------------------\n\n";
            cout << "1 - FASE 1      (15 SEGUNDOS)\n\n";
            cout << "2 - FASE 2      (10 SEGUNDOS)\n\n";
            cout << "3 - FASE 3      (08 SEGUNDOS)\n\n";
            cout << "4 - Retornar ao menu principal\n\n";
            cout << "----------------------------------------\n\n";

            cout << "Escolha sua FASE: ";
            cin >> iFASE;
            system("cls");
            switch (iFASE)
            {
            case 1:
                Sleep(0500);
                system("cls");
                ipontuacaoN3F1 += NIVEL3fase1();
                Sleep(10000);
                system("cls");
                break;
            //return main ();
            case 2:
                Sleep(0500);
                system("cls");
                ipontuacaoN3F2 += NIVEL3fase2();
                Sleep(10000);
                system("cls");
                break;
            //return main ();
            case 3:
                Sleep(0500);
                system("cls");
                ipontuacaoN3F3 += NIVEL3fase3();
                Sleep(10000);
                system("cls");
                break;
            // return main ();
            case 4:
                cout << "Voc� saiu do jogo.";
                break;
            default:
                cout << "Valor Inv�lido!\n";
                Sleep(6000);
                system("cls");
                break;
                // return main ();
            }
            break;
        case 4:
            cout << "\n\n\n\n Voc� saiu do jogo.\n\n\n\n";
            break;

        case 5:
            //ipontuacaoN1F1 += NIVEL1fase1();
            cout << "\nSEU DESEMPENHO: ";
            SetColor(13);
            cout << "\n\n\n\n N�VEL 1: \n\n ";
            cout << "\t FASE 1: " <<ipontuacaoN1F1;
            cout << "\t FASE 2: " <<ipontuacaoN1F2;
            cout << "\t FASE 3: " <<ipontuacaoN1F3;
            SetColor(10);
            cout << "\n\n\n\n N�VEL 2: \n\n ";
            cout << "\t FASE 1: "<< ipontuacaoN2F1;
            cout << "\t FASE 2: "<< ipontuacaoN2F2;
            cout << "\t FASE 3: "<< ipontuacaoN2F3;
            SetColor(11);
            cout << "\n\n\n\n N�VEL 3: \n\n ";
            cout << "\t FASE 1: "<<ipontuacaoN3F1;
            cout << "\t FASE 2: "<<ipontuacaoN3F2;
            cout << "\t FASE 3: "<<ipontuacaoN3F3;
            SetColor(15);
            Sleep(10000);
            system("cls");
            break;
        // return main ();
        default:
            cout << "Valor Inv�lido!\n";
            Sleep(6000);
            system("cls");
            break;

            // return main ();
        }


    }
    return 0;
}

