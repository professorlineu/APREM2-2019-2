#include "fasedificil.h"
#include <iostream>
#include <locale.h>
#include <cstdlib>
#include <windows.h>
#include <conio.h>
#include <time.h>
#include "inicio.h"
#include "carreg.h"

using namespace std;

void fasedificil()
{
     int iChoice=0;
        int iResposta = 0;
        int iPontuacaoD = 0;
        int iEscolha = 0;

        cout << "\n\tVoc� est� na fase dif�cil."
             << "\n\n\tAperte 0 para sair.";

        Sleep(2000);

        system("cls");

        cout << "\n\n\t ---- N�VEL 1 -->"
             << "\n\n\t Descubra a s�rie a partir de: "
             << "\n\n\t 'Yellow Umbrella' ";

        cout << "\n\n\t 1 - FRIENDS"
             << "\n\t 2 - How I met your mother"
             << "\n\t 3 - Brokylin 99";

        cout << "\n\t Resposta: ";
        cin  >> iResposta;

        Sleep (1000);

        if (iResposta == 2)
        {
        cout << "\n\tResposta Correta!";

        iPontuacaoD = iPontuacaoD + 250;
        }

        else if (iResposta == 0)
        {
        system("cls");
        carreg();
        inicio();
        }

        else
        {
        cout << "\n\tResposta Errada.";

        iPontuacaoD= iPontuacaoD - 50;

        }

        Sleep(1000);

        system("cls");

        cout << "\n\n\t ---- N�VEL 2 -->"
             << "\n\n\t Descubra o personagem: "
             << "\n\n\t 'Posso fazer isso o dia todo.' ";

        cout << "\n\n\t 1 - Homem Aranha"
             << "\n\t 2 - Capit�o Am�rica"
             << "\n\t 3 - Homem de Ferro";

        cout << "\n\t Resposta: ";
        cin  >> iResposta;

        Sleep (1000);

        if (iResposta == 2)
        {
        cout << "\n\t Resposta Correta!";

        iPontuacaoD = iPontuacaoD + 250;
        }

        else if (iResposta == 0)
        {
        system("cls");
        carreg();
        inicio();
        }

        else
        {
        cout << "\n\t Resposta Errada.";

        iPontuacaoD = iPontuacaoD - 50;

        }

        Sleep (1000);

        system("cls");

        cout << "\n\n\t ---- N�VEL 3 -->"
             << "\n\n\t Descubra a s�rie a partir da frase:"
             << "\n\n\t 'Isso n�o � mais uma democracia.'";

        cout << "\n\n\t 1 - The 100"
             << "\n\t 2 - Riverdale"
             << "\n\t 3 - The Walking Dead";

        cout << "\n\t Resposta: ";
        cin  >> iResposta;

        Sleep (1000);

        if (iResposta == 3)
        {
        cout << "\n\t Resposta Correta!";

        iPontuacaoD = iPontuacaoD + 250;
        }

        else if (iResposta == 0)
        {
        system("cls");
        carreg();
        inicio();
        }

        else
        {
        cout << "\n\t Resposta Errada.";

        iPontuacaoD = iPontuacaoD - 50;

        }

        Sleep (1000);

        system("cls");

        cout << "\n\n\t ---- N�VEL 4 -->"
             << "\n\n\t Em que filme a base de Scarif � destru�da?";

        cout << "\n\n\t 1 - Rogue One"
             << "\n\t 2 - O imp�rio contra ataca"
             << "\n\t 3 - A vingan�a dos Sith";

        cout << "\n\t Resposta: ";
        cin  >> iResposta;

        Sleep (1000);

        if (iResposta == 1)
        {
        cout << "\n\t Resposta Correta!";

        iPontuacaoD = iPontuacaoD + 250;
        }
        else if (iResposta == 0)
        {
        system("cls");
        carreg();
        inicio();
        }

        else
        {
        cout << "\n\t Resposta Errada.";

        iPontuacaoD = iPontuacaoD - 50;

        }

        Sleep (1000);

        system("cls");

        cout << "\n\n\t ---- N�VEL 5 -->"
             << "\n\n\t Qual � o nome do amigo tagarela do Scott Lang? ";

        cout << "\n\n\t 1 - Rico"
             << "\n\t 2 - Luis"
             << "\n\t 3 - Pablo";

        cout << "\n\t Resposta: ";
        cin  >> iResposta;

        Sleep (1000);

        if (iResposta == 2)
        {
        cout << "\n\t Resposta Correta!";

        iPontuacaoD = iPontuacaoD + 250;
        }
        else if (iResposta == 0)
        {
        system("cls");
        carreg();
        inicio();
        }

        else
        {
        cout << "\n\t Resposta Errada.";

        iPontuacaoD = iPontuacaoD - 50;

        }


        Sleep (2000);

        system("cls");

        cout << "\n\n\tP";
        Sleep(100);

        cout << "on";
        Sleep(100);

        cout << "tu";
        Sleep(100);

        cout << "a";
        Sleep(100);

        cout << "��";
        Sleep(100);

        cout << "o:";
        Sleep(100);

        cout << " " << iPontuacaoD << " pontos.";
        Sleep(1000);

        if (iPontuacaoD == 1250)
        {
        cout << "\n\n\tVoc� acertou 5/5."; Sleep(400);
        cout << "\n\tSeu conhecimento da cultura pop � �timo!";
        }
        else if (iPontuacaoD == 950)
        {
        cout << "\n\n\tVoc� acertou 4/5."; Sleep(400);
        cout << "\n\tFoi por pouco, talvez voc� tenha deixado de assistir um filme.";
        }
        else if (iPontuacaoD == 650)
        {
        cout << "\n\n\tVoc� acertou 3/5."; Sleep(400);
        cout << "\n\tSer� que foi aquela s�rie que voc� disse que n�o gostava?";
        }
        else if (iPontuacaoD == 350)
        {
        cout << "\n\n\tVoc� acertou 2/5."; Sleep(400);
        cout << "\n\t� como dizem... 1 � pouco, 2 � bom, 3 � demais.";
        }
        else if (iPontuacaoD == 50)
        {
        cout << "\n\n\tVoc� acertou 1/5."; Sleep(400);
        cout << "\n\tVou fingir que voc� estuda muito e n�o tem tempo de assistir muitos filmes, ok?";
        }
        else
        {
        cout << "\n\n\tVoc� acertou 0/5."; Sleep(400);
        cout << "\n\tSer� que estava t�o dif�cil assim?"; Sleep(400);
        cout << " vou dar uma olhada nos meus c�digos...";
        }

        Sleep(1000);

        cout << "\n\n\n\tAperte qualquer tecla...";
        getch();

        system("cls");
        carreg();
        inicio();

        }
