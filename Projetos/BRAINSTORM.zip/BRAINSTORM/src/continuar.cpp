#include "continuar.h"
#include <iostream>
#include <locale.h>
#include <cstdlib>
#include <windows.h>
#include <conio.h>
#include <time.h>
#include "inicio.h"
#include "carreg.h"
#include "fasefacil.h"
#include "fasemedia.h"
#include "fasedificil.h"

using namespace std;

void continuar()

    {

    int i = 0;
    int iEscolha = 0;

    cout << "\n\n\t--";

    for (i=0; i<4; i++)
    {
    cout << "----";
    Sleep(50);
    }

    cout << "\n\t|                |";
    Sleep(50);

    cout << "\n\t| ESCOLHA A FASE |";
    Sleep(50);

    cout << "\n\t|                |";
    Sleep(50);

    cout << "\n\t|     1 EASY     |";
    Sleep(50);

    cout << "\n\t|    2 MEDIUM    |";
    Sleep(50);

    cout << "\n\t|     3 HARD     |";
    Sleep(50);

    cout << "\n\t|    0 VOLTAR    |";
    Sleep(50);

    cout << "\n\t|                |";
    Sleep(50);

    cout << "\n\t--";

    for (i=0; i<4; i++)
    {
    cout << "----";
    Sleep(50);
    }

    cout << "\n\n\t         ";
    cin  >> iEscolha;

    if (iEscolha == 1)
    {
    system("cls");
    carreg();
    fasefacil();
    }
    else if (iEscolha == 2)
    {
    system("cls");
    carreg();
    fasemedia();
    }
    else if (iEscolha == 3)
    {
    system("cls");
    carreg();
    fasedificil();
    }
    else if (iEscolha == 0)
    {
    system("cls");
    carreg();
    inicio();
    }
    else
    {
    cout << "\n\n\t  Op��o inv�lida.";
    Sleep(700);
    system("cls");
    continuar();
    }

    }





