#include "carreg.h"
#include <iostream>
#include <locale.h>
#include <cstdlib>
#include <windows.h>
#include <conio.h>
#include <time.h>

using namespace std;

 void carreg()
    {
     system("cls");

    cout << "\n\n\tCar";
    Sleep(100);

    cout << "re";
    Sleep(100);

    cout << "gan";
    Sleep(100);

    cout << "do.";
    Sleep(100);

    cout << "..";
    Sleep(100);

    system("cls");

    cout << "\n\n\tCarregando..";
    Sleep(100);

    system("cls");

    cout << "\n\n\tCarregando.";
    Sleep(100);

    system("cls");

    cout << "\n\n\tCarregando...";
    Sleep(100);

    system("cls");

    cout << "\n\n\tCarregando....";
    Sleep(100);

    system("cls");

    cout << "\n\n\tCarregando..";
    Sleep(100);

    system("cls");

    cout << "\n\n\tCarregando.";
    Sleep(100);

    system("cls");

    cout << "\n\n\tCarregando...";
    Sleep(100);

    system("cls");

    cout << "\n\n\tCarregando....";
    Sleep(100);

    system("cls");

    cout << "\n\n\tCarregando.";
    Sleep(200);

    system("cls");

    }


