#include "sair.h"
#include <iostream>
#include <locale.h>
#include <cstdlib>
#include <windows.h>
#include <conio.h>
#include <time.h>

using namespace std;

 void sair()
    {

        cout << "\n\n\t   A";
        Sleep(50);

        cout << "t�";
        Sleep(100);

        cout << " ";
        Sleep(50);

        cout << "M";
        Sleep(50);

        cout << "ai";
        Sleep(50);

        cout << "s";
        Sleep(50);

        cout << "!!";
        Sleep(300);

        cout << "\n\n\n\n";

    }

