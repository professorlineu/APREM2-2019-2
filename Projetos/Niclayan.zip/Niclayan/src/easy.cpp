#include <iostream>
#include <locale.h>
#include <cstdlib>
#include <time.h>
#include <windows.h>

using namespace std;

void easy ()
{
    int iColor = 0;
    int iMode = 0;
    int iLevel = 0;
    int i = 0;
    int d = 0;
    int g = 0;
    int t = 0;
    int s = 0;
    int r = 0;
    int r2 = 0;
    int r3 = 0;
    int r4 = 0;
    float fAnswer = 0;

    while (s==0)
            {
                d=d-d, i=i-i, g=g-g, s=s-s, t=t-t;
                system("cls");
                cout << "Welcome to easy mode.";
                //Sleep (3000);
                system("cls");

                cout << "/***************\n\n";
                cout << "Chose the level\n\n";
                cout << "1- Level 1\n\n";
                cout << "2- Level 2 \n\n";
                cout << "3- Level 3 \n\n";
                cout << "4- Exit\n\n\n";
                cout << "***************/\n";
                cin >> iLevel;

                switch (iLevel)
                {
                case 1:
                    system("cls");
                    cout << "Welcome to level 1.";
                   // Sleep (3000);
                    system("cls");

                    while (g == 0)
                    {
                        while (i < 10 && d == 0)
                        {
                            system("color F1");
                            srand(time(NULL));
                            r3=rand()%10+1;


                            if (r3%2 == 0)
                            {
                                system("cls");
                                srand(time(NULL));
                                r=rand()%10+1;
                                r2=rand()%10+1;
                                cout << r << " + " << r2 << "= ";
                                cin >> fAnswer;

                                if (fAnswer == r + r2)
                                {
                                    system("color A1");
                                    cout << "It's correct!\n";
                                    ++i;
                                    Sleep(2000);
                                    system("cls");
                                }
                                else
                                {

                                    srand(time(NULL));
                                    r4=rand()%10+1;

                                    if (r4%2==0)
                                    {
                                        cout << "It isan't correct. Try again.\n";
                                        d++;
                                        Sleep(2000);
                                    }

                                    if (r4%2!=0)
                                    {
                                        cout << "Your math is not good. Try again.";
                                        d++;
                                        Sleep(2000);
                                    }
                                }
                            }


                            if (r3%2 !=0)
                            {
                                system("cls");
                                srand(time(NULL));
                                r=rand()%10+1;
                                r2=rand()%10+1;
                                cout << r2 << " - " <<r << "= ";
                                cin >> fAnswer;
                                if (fAnswer == r2 - r)
                                {
                                    cout << "It's correct!\n";
                                    i++;
                                    Sleep(2000);
                                    system("cls");
                                }
                                else
                                {
                                    srand(time(NULL));
                                    r4=rand()%10+1;

                                    if (r4%2==0)
                                    {
                                        cout << "It isan't correct. Try again.\n";
                                        d++;
                                        Sleep(2000);
                                    }

                                    if (r4%2!=0)
                                    {
                                        cout << "Your math is not good. Try again.";
                                        d++;
                                        Sleep(2000);
                                    }
                                }

                            }

                            g++;
                        }

                    } // the end of the big while
                    if(i==10)
                    {
                        cout << "Congratulations to complete the level 1!";
                        Sleep(3000);
                        system("cls");
                    }
                    break;

                case 2:
                    system("cls");
                    cout << "Welcome to level 2.";
                    Sleep (3000);
                    system("cls");

                    while (g == 0)
                    {
                        while (i < 10 && d == 0)
                        {
                            srand(time(NULL));
                            r3=rand()%100+1;



                            if (r3%2 == 0)
                            {
                                system("cls");
                                srand(time(NULL));
                                r=rand()%100+1;
                                r2=rand()%100+1;
                                cout << r << " + " << r2 << "= ";
                                cin >> fAnswer;

                                if (fAnswer == r + r2)
                                {
                                    cout << "It's correct!\n";
                                    ++i;
                                    Sleep(2000);
                                    system("cls");
                                }
                                else
                                {
                                    srand(time(NULL));
                                    r4=rand()%10+1;

                                    if (r4%2==0)
                                    {
                                        cout << "It isan't correct. Try again.\n";
                                        d++;
                                        Sleep(2000);
                                    }

                                    if (r4%2!=0)
                                    {
                                        cout << "Your math is not good. Try again.";
                                        d++;
                                        Sleep(2000);
                                    }
                                }
                            }


                            if (r3%2 !=0)
                            {
                                system("cls");
                                srand(time(NULL));
                                r=rand()%100+1;
                                r2=rand()%100+1;
                                cout << r2 << " - " <<r << "= ";
                                cin >> fAnswer;
                                if (fAnswer == r2 - r)
                                {
                                    cout << "It's correct!\n";
                                    i++;
                                    Sleep(2000);
                                    system("cls");
                                }
                                else
                                {
                                    srand(time(NULL));
                                    r4=rand()%10+1;

                                    if (r4%2==0)
                                    {
                                        cout << "It isan't correct. Try again.\n";
                                        d++;
                                        Sleep(2000);
                                    }

                                    if (r4%2!=0)
                                    {
                                        cout << "Your math is not good. Try again.";
                                        d++;
                                        Sleep(2000);
                                    }
                                }

                            }

                            g++;
                        }

                    } // the end of the big while
                    if(i==10)
                    {
                        cout << "Congratulations to complete the level 2!";
                        Sleep(3000);
                        system("cls");
                    }
                    break;

                case 3:
                    system("cls");
                    cout << "Welcome to level 3.";
                    Sleep (3000);
                    system("cls");

                    while (g == 0)
                    {
                        while (i < 10 && d == 0)
                        {
                            srand(time(NULL));
                            r3=rand()%1000+1;



                            if (r3%2 == 0)
                            {
                                system("cls");
                                srand(time(NULL));
                                r=rand()%1000+1;
                                r2=rand()%1000+1;
                                cout << r << " + " << r2 << "= ";
                                cin >> fAnswer;

                                if (fAnswer == r + r2)
                                {
                                    cout << "It's correct!\n";
                                    ++i;
                                    Sleep(2000);
                                    system("cls");
                                }
                                else
                                {
                                    srand(time(NULL));
                                    r4=rand()%10+1;

                                    if (r4%2==0)
                                    {
                                        cout << "It isan't correct. Try again.\n";
                                        d++;
                                        Sleep(2000);
                                    }

                                    if (r4%2!=0)
                                    {
                                        cout << "Your math is not good. Try again.";
                                        d++;
                                        Sleep(2000);
                                    }
                                }
                            }


                            if (r3%2 !=0)
                            {
                                system("cls");
                                srand(time(NULL));
                                r=rand()%1000+1;
                                r2=rand()%1000+1;
                                cout << r2 << " - " <<r << "= ";
                                cin >> fAnswer;
                                if (fAnswer == r2 - r)
                                {
                                    cout << "It's correct!\n";
                                    i++;
                                    Sleep(2000);
                                    system("cls");
                                }
                                else
                                {
                                    srand(time(NULL));
                                    r4=rand()%10+1;

                                    if (r4%2==0)
                                    {
                                        cout << "It isan't correct. Try again.\n";
                                        d++;
                                        Sleep(2000);
                                    }

                                    if (r4%2!=0)
                                    {
                                        cout << "Your math is not good. Try again.";
                                        d++;
                                        Sleep(2000);
                                    }
                                }

                            }

                            g++;
                        }

                    } // the end of the big while
                    if(i==10)
                    {
                        cout << "Congratulations to complete the level 3";
                        Sleep(3000);
                        system("cls");
                    }
                    break;

                case 4:
                    ++s;
                    break;

                default:
                    system("cls");
                    cout << "Invalid command. Try again,";
                    Sleep(1500);

                } //The end of switch level

            } //The end of while s

}
