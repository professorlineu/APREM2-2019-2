#include <iostream>
#include <locale.h>
#include <cstdlib>
#include <time.h>
#include <windows.h>

using namespace std;

void SetColor(int forgC);

int main()
{
    //Declara��o de vari�veis
    int iColor = 0;
    int iMode = 0;
    int iLevel = 0;
    int i = 0;
    int d = 0;
    int g = 0;
    int t = 0;
    int s = 0;
    int r = 0;
    int r2 = 0;
    int r3 = 0;
    int r4 = 0;
    float fAnswer = 0;
    //Configura��o da tela de sa�da

    setlocale(LC_ALL,"");
    system("color F1");

    //C�digo do programa

    srand(time(NULL));

    SetColor(iColor);
    cout << "Welcome to the best game in the world";
    //Sleep (3000);
    system("cls");

    SetColor(iColor);
    cout << "Welcome to Niclyan!";
    //Sleep (3000);
    system("cls");

    while (t == 0)
    {
        system("cls");
        d=d-d, i=i-i, g=g-g, s=s-s, t=t-t;

        cout << "/***************\n\n";
        cout << "Chose the mode\n\n";
        cout << "1- Easy \n\n";
        cout << "2- Medium \n\n";
        cout << "3- Hard \n\n";
        cout << "4- Exit\n\n\n";
        cout << "***************/\n";
        cin >> iMode;

        switch (iMode)
        {
        case 1:
           void easy();
            break;

        case 2:
            while (s==0)
            {
                d=d-d, i=i-i, g=g-g, s=s-s, t=t-t;
                system("cls");
                cout << "Welcome to medium mode.";
                Sleep (3000);
                system("cls");

                cout << "/***************\n\n";
                cout << "Chose the level\n\n";
                cout << "1- Level 1\n\n";
                cout << "2- Level 2 \n\n";
                cout << "3- Level 3 \n\n";
                cout << "4- Exit\n\n\n";
                cout << "***************/\n";
                cin >> iLevel;

                switch (iLevel)
                {
                case 1:
                    system("cls");
                    cout << "Welcome to level 1.";
                    Sleep (3000);
                    system("cls");

                    while (g == 0)
                    {
                        while (i < 10 && d == 0)
                        {
                            srand(time(NULL));
                            r3=rand()%10+1;


                            if (r3%2 == 0)
                            {
                                system("cls");
                                srand(time(NULL));
                                r=rand()%10+1;
                                r2=rand()%10+1;
                                cout << r << " . " << r2 << "= ";
                                cin >> fAnswer;

                                if (fAnswer == r * r2)
                                {
                                    cout << "It's correct!\n";
                                    ++i;
                                    Sleep(2000);
                                    system("cls");
                                }
                                else
                                {

                                    srand(time(NULL));
                                    r4=rand()%10+1;

                                    if (r4%2==0)
                                    {
                                        cout << "It isan't correct. Try again.\n";
                                        d++;
                                        Sleep(2000);
                                    }

                                    if (r4%2!=0)
                                    {
                                        cout << "Your math is not good. Try again.";
                                        d++;
                                        Sleep(2000);
                                    }
                                }
                            }


                            if (r3%2 !=0)
                            {
                                system("cls");
                                srand(time(NULL));
                                r=rand()%10+1;
                                r2=rand()%10+1;
                                cout << r2 << " / " <<r << "= ";
                                cin >> fAnswer;
                                if (fAnswer == r2 / r)
                                {
                                    cout << "It's correct!\n";
                                    i++;
                                    Sleep(2000);
                                    system("cls");
                                }
                                else
                                {
                                    srand(time(NULL));
                                    r4=rand()%10+1;

                                    if (r4%2==0)
                                    {
                                        cout << "It isan't correct. Try again.\n";
                                        d++;
                                        Sleep(2000);
                                    }

                                    if (r4%2!=0)
                                    {
                                        cout << "Your math is not good. Try again.";
                                        d++;
                                        Sleep(2000);
                                    }
                                }

                            }

                            g++;
                        }

                    } // the end of the big while
                    if(i==10)
                    {
                        cout << "Congratulations to complete the level 1!";
                        Sleep(3000);
                        system("cls");
                    }
                    break;

                case 2:
                    system("cls");
                    cout << "Welcome to level 2.";
                    Sleep (3000);
                    system("cls");

                    while (g == 0)
                    {
                        while (i < 10 && d == 0)
                        {
                            srand(time(NULL));
                            r3=rand()%100+1;



                            if (r3%2 == 0)
                            {
                                system("cls");
                                srand(time(NULL));
                                r=rand()%100+1;
                                r2=rand()%100+1;
                                cout << r << " . " << r2 << "= ";
                                cin >> fAnswer;

                                if (fAnswer == r * r2)
                                {
                                    cout << "It's correct!\n";
                                    ++i;
                                    Sleep(2000);
                                    system("cls");
                                }
                                else
                                {
                                    srand(time(NULL));
                                    r4=rand()%10+1;

                                    if (r4%2==0)
                                    {
                                        cout << "It isan't correct. Try again.\n";
                                        d++;
                                        Sleep(2000);
                                    }

                                    if (r4%2!=0)
                                    {
                                        cout << "Your math is not good. Try again.";
                                        d++;
                                        Sleep(2000);
                                    }
                                }
                            }


                            if (r3%2 !=0)
                            {
                                system("cls");
                                srand(time(NULL));
                                r=rand()%100+1;
                                r2=rand()%100+1;
                                cout << r2 << " / " <<r << "= ";
                                cin >> fAnswer;
                                if (fAnswer == r2 / r)
                                {
                                    cout << "It's correct!\n";
                                    i++;
                                    Sleep(2000);
                                    system("cls");
                                }
                                else
                                {
                                    srand(time(NULL));
                                    r4=rand()%10+1;

                                    if (r4%2==0)
                                    {
                                        cout << "It isan't correct. Try again.\n";
                                        d++;
                                        Sleep(2000);
                                    }

                                    if (r4%2!=0)
                                    {
                                        cout << "Your math is not good. Try again.";
                                        d++;
                                        Sleep(2000);
                                    }
                                }

                            }

                            g++;
                        }

                    } // the end of the big while
                    if(i==10)
                    {
                        cout << "Congratulations to complete the level 2!";
                        Sleep(3000);
                        system("cls");
                    }
                    break;

                case 3:
                    system("cls");
                    cout << "Welcome to level 3.";
                    Sleep (3000);
                    system("cls");

                    while (g == 0)
                    {
                        while (i < 10 && d == 0)
                        {
                            srand(time(NULL));
                            r3=rand()%1000+1;



                            if (r3%2 == 0)
                            {
                                system("cls");
                                srand(time(NULL));
                                r=rand()%1000+1;
                                r2=rand()%1000+1;
                                cout << r << " . " << r2 << "= ";
                                cin >> fAnswer;

                                if (fAnswer == r * r2)
                                {
                                    cout << "It's correct!\n";
                                    ++i;
                                    Sleep(2000);
                                    system("cls");
                                }
                                else
                                {
                                    srand(time(NULL));
                                    r4=rand()%10+1;

                                    if (r4%2==0)
                                    {
                                        cout << "It isan't correct. Try again.\n";
                                        d++;
                                        Sleep(2000);
                                    }

                                    if (r4%2!=0)
                                    {
                                        cout << "Your math is not good. Try again.";
                                        d++;
                                        Sleep(2000);
                                    }
                                }
                            }


                            if (r3%2 !=0)
                            {
                                system("cls");
                                srand(time(NULL));
                                r=rand()%1000+1;
                                r2=rand()%1000+1;
                                cout << r2 << " / " <<r << "= ";
                                cin >> fAnswer;
                                if (fAnswer == r2 / r)
                                {
                                    cout << "It's correct!\n";
                                    i++;
                                    Sleep(2000);
                                    system("cls");
                                }
                                else
                                {
                                    srand(time(NULL));
                                    r4=rand()%10+1;

                                    if (r4%2==0)
                                    {
                                        cout << "It isan't correct. Try again.\n";
                                        d++;
                                        Sleep(2000);
                                    }

                                    if (r4%2!=0)
                                    {
                                        cout << "Your math is not good. Try again.";
                                        d++;
                                        Sleep(2000);
                                    }
                                }

                            }

                            g++;
                        }

                    } // the end of the big while
                    if(i==10)
                    {
                        cout << "Congratulations to complete the level 3";
                        Sleep(3000);
                        system("cls");
                    }
                    break;

                case 4:
                    ++s;
                    break;

                default:
                    system("cls");
                    cout << "Invalid command. Try again,";
                    Sleep(1500);

                } //The end of switch level

            } //The end of while s
            break;

        case 3:
            while (s==0)
            {
                d=d-d, i=i-i, g=g-g, s=s-s, t=t-t;

                system("cls");
                cout << "Welcome to hard mode.";
                Sleep (3000);
                system("cls");

                cout << "/***************\n\n";
                cout << "Chose the level\n\n";
                cout << "1- Level 1\n\n";
                cout << "2- Level 2 \n\n";
                cout << "3- Level 3 \n\n";
                cout << "4- Exit\n\n\n";
                cout << "***************/\n";
                cin >> iLevel;

                switch (iLevel)
                {
                case 1:
                    system("cls");
                    cout << "Welcome to level 1.";
                    Sleep (3000);
                    system("cls");

                    while (g == 0)
                    {
                        while (i < 10 && d == 0)
                        {

                            system("cls");
                            srand(time(NULL));
                            r=rand()%10+1;

                            cout << r << " . " << r << "= ";
                            cin >> fAnswer;

                            if (fAnswer == r *r)
                            {
                                system("cls");
                                cout << "It's correct!\n";
                                ++i;
                                Sleep(2000);
                                system("cls");
                            }
                            else
                            {

                                srand(time(NULL));
                                r4=rand()%10+1;

                                if (r4%2==0)
                                {
                                    cout << "It isan't correct. Try again.\n";
                                    d++;
                                    Sleep(2000);
                                }

                                if (r4%2!=0)
                                {
                                    cout << "Your math is not good. Try again.";
                                    d++;
                                    Sleep(2000);
                                }
                            }



                            g++;
                        }

                    } // the end of the big while
                    if(i==10)
                    {
                        cout << "Congratulations to complete the level 1!";
                        Sleep(3000);
                        system("cls");
                    }
                    break;

                case 2:
                    system("cls");
                    cout << "Welcome to level 2.";
                    Sleep (3000);
                    system("cls");

                    while (g == 0)
                    {
                        while (i < 10 && d == 0)
                        {

                            system("cls");
                            srand(time(NULL));
                            r=rand()%100+1;

                            cout << r << " . " << r << "= ";
                            cin >> fAnswer;

                            if (fAnswer == r * r)
                            {
                                system("cls");
                                cout << "It's correct!\n";
                                ++i;
                                Sleep(2000);
                                system("cls");
                            }
                            else
                            {
                                srand(time(NULL));
                                r4=rand()%10+1;

                                if (r4%2==0)
                                {
                                    cout << "It isan't correct. Try again.\n";
                                    d++;
                                    Sleep(2000);
                                }

                                if (r4%2!=0)
                                {
                                    cout << "Your math is not good. Try again.";
                                    d++;
                                    Sleep(2000);
                                }
                            }


                            g++;
                        }

                    } // the end of the big while
                    if(i==10)
                    {
                        cout << "Congratulations to complete the level 2!";
                        Sleep(3000);
                        system("cls");
                    }
                    break;

                case 3:
                    system("cls");
                    cout << "Welcome to level 3.";
                    Sleep (3000);
                    system("cls");

                    while (g == 0)
                    {
                        while (i < 10 && d == 0)
                        {

                            system("cls");
                            srand(time(NULL));
                            r=rand()%1000+1;

                            cout << r << " . " << r << "= ";
                            cin >> fAnswer;

                            if (fAnswer == r * r)
                            {
                                system("cls");
                                cout << "It's correct!\n";
                                ++i;
                                Sleep(2000);
                                system("cls");
                            }
                            else
                            {
                                srand(time(NULL));
                                r4=rand()%10+1;

                                if (r4%2==0)
                                {
                                    cout << "It isan't correct. Try again.\n";
                                    d++;
                                    Sleep(2000);
                                }

                                if (r4%2!=0)
                                {
                                    cout << "Your math is not good. Try again.";
                                    d++;
                                    Sleep(2000);
                                }
                            }





                            g++;
                        }

                    } // the end of the big while
                    if(i==10)
                    {
                        cout << "Congratulations to complete the level 3";
                        Sleep(3000);
                        system("cls");
                    }
                    break;

                case 4:
                    ++s;
                    break;

                default:
                    system("cls");
                    cout << "Invalid command. Try again,";
                    Sleep(1500);

                } //The end of switch level

            } //The end of while s
            break;

        case 4:
            system("cls");
            cout << "By!";
            Sleep(2000);
            ++t;
            break;

        default:
            system("cls");
            cout << "Invalid command. Try again.";
            Sleep(1500);


        } //The end of switch mode

    } //the end of the bigger while
    return 0;
}

void SetColor(int ForgC)
{
    WORD wColor;
    //We will need this handle to get the current background attribute
    HANDLE hStdOut = GetStdHandle(STD_OUTPUT_HANDLE);
    CONSOLE_SCREEN_BUFFER_INFO csbi;

    //We use csbi for the wAttributes word.
    if(GetConsoleScreenBufferInfo(hStdOut, &csbi))
    {
        //Mask out all but the background attribute, and add in the forgournd color
        wColor = (csbi.wAttributes & 0xF0) + (ForgC & 0x0F);
        SetConsoleTextAttribute(hStdOut, wColor);
    }
    return;
}
