#include "fasemedia.h"
#include <iostream>
#include <locale.h>
#include <cstdlib>
#include <windows.h>
#include <conio.h>
#include <time.h>
#include "inicio.h"
#include "carreg.h"
#include "fasedificil.h"

using namespace std;

 void fasemedia()
    {
        int iChoice = 0;
        int iResposta = 0;
        int iEscolha = 0;
        int iPontuacao2 = 0;

        cout << "\n\tVoc� est� na fase m�dia."
             << "\n\tAperte 0 para sair.";

        Sleep(1000);

        system("cls");

        cout << "\n\n\t ---- N�VEL 1 -->"
             << "\n\n\t Quantas estrelas da morte existiram? ";

        cout << "\n\t Resposta: ";
        cin  >> iResposta;

        Sleep (1000);

        if (iResposta == 2)
        {
        cout << "\n\t Resposta Correta!";

        iPontuacao2 = iPontuacao2 + 150;
        }
        else if (iResposta == 0)
        {
        system("cls");
        carreg();
        inicio();
        }

        else
        {
        cout << "\n\t Resposta Errada.";

        iPontuacao2 = iPontuacao2 - 30;

        }

        Sleep(1000);

        system("cls");

        cout << "\n\n\t ---- N�VEL 2 -->"
             << "\n\n\t Descubra a s�rie: "
             << "\n\n\t 'Heisenberg' ";

        cout << "\n\n\t 1 - Altered Carbon"
             << "\n\t 2 - Breaking Bad"
             << "\n\t 3 - DARK";

        cout << "\n\t Resposta: ";
        cin  >> iResposta;

        Sleep (1000);

        if (iResposta == 2)
        {
        cout << "\n\t Resposta Correta!";

        iPontuacao2 = iPontuacao2 + 150;
        }
        else if (iResposta == 0)
        {
        system("cls");
        carreg();
        inicio();
        }

        else
        {
        cout << "\n\t Resposta Errada.";

        iPontuacao2 = iPontuacao2 - 30;

        }

        Sleep (1000);

        system("cls");

        cout << "\n\n\t ---- N�VEL 3 -->"
             << "\n\n\t Qual foi o primeiro filme a ser lan�ado da saga STAR WARS? ";

        cout << "\n\n\t 1 - A origem dos Jedi"
             << "\n\t 2 - Amea�a Fantasma"
             << "\n\t 3 - Uma nova esperan�a";

        cout << "\n\t Resposta: ";
        cin  >> iResposta;

        Sleep (1000);

        if (iResposta == 3)
        {
        cout << "\n\t Resposta Correta!";

        iPontuacao2 = iPontuacao2 + 150;
        }
        else if (iResposta == 0)
        {
        system("cls");
        carreg();
        inicio();
        }

        else
        {
        cout << "\n\t Resposta Errada.";

        iPontuacao2 = iPontuacao2 - 30;

        }

        Sleep (1000);

        system("cls");

        cout << "\n\n\t ---- N�VEL 4 -->"
             << "\n\n\t Vetor Gradiente? ";

        cout << "\n\n\t 1 - C�lculo I "
             << "\n\t 2 - Geometria Anal�tica"
             << "\n\t 3 - C�lculo II";

        cout << "\n\t Resposta: ";
        cin  >> iResposta;

        Sleep (1000);

        if (iResposta == 3)
        {
        cout << "\n\t Resposta Correta!";

        iPontuacao2 = iPontuacao2 + 150;
        }
        else if (iResposta == 0)
        {
        system("cls");
        carreg();
        inicio();
        }

        else
        {
        cout << "\n\t Resposta Errada.";

        iPontuacao2 = iPontuacao2 - 30;

        }

        Sleep (1000);

        system("cls");

        cout << "\n\n\t ---- N�VEL 5 -->"
             << "\n\n\t Quantos filmes do Senhor dos An�is existem? ";

        cout << "\n\t Resposta: ";
        cin  >> iResposta;

        Sleep (1000);

        if (iResposta == 3)
        {
        cout << "\n\t Resposta Correta!";

        iPontuacao2 = iPontuacao2 + 150;
        }
        else if (iResposta == 0)
        {
        system("cls");
        carreg();
        inicio();
        }

        else
        {
        cout << "\n\t Resposta Errada.";

        iPontuacao2 = iPontuacao2 - 30;

        }

        Sleep (2000);

        system("cls");

        cout << "\n\n\tP";
        Sleep(100);

        cout << "on";
        Sleep(100);

        cout << "tu";
        Sleep(100);

        cout << "a";
        Sleep(100);

        cout << "��";
        Sleep(100);

        cout << "o:";
        Sleep(100);

        cout << " " << iPontuacao2 << " pontos.";

        if (iPontuacao2 == 750)
        {
        cout << "\n\n\tVoc� acertou 5/5."; Sleep(400);
        cout << "\n\tSeu conhecimento da cultura pop � �timo!";
        }
        else if (iPontuacao2 == 570)
        {
        cout << "\n\n\tVoc� acertou 4/5."; Sleep(400);
        cout << "\n\tFoi por pouco, talvez voc� tenha deixado de assistir um filme.";
        }
        else if (iPontuacao2 == 390)
        {
        cout << "\n\n\tVoc� acertou 3/5."; Sleep(400);
        cout << "\n\tSer� que foi aquela s�rie que voc� disse que n�o gostava?";
        }
        else if (iPontuacao2 == 210)
        {
        cout << "\n\n\tVoc� acertou 2/5."; Sleep(400);
        cout << "\n\t� como dizem... 1 � pouco, 2 � bom, 3 � demais.";
        }
        else if (iPontuacao2 == 30)
        {
        cout << "\n\n\tVoc� acertou 1/5."; Sleep(400);
        cout << "\n\tVou fingir que voc� estuda muito e n�o tem tempo de assistir muitos filmes, ok?";
        }
        else
        {
        cout << "\n\n\tVoc� acertou 0/5."; Sleep(400);
        cout << "\n\tSer� que estava t�o dif�cil assim?"; Sleep(400);
        cout << " vou dar uma olhada nos meus c�digos...";
        }

        Sleep(1000);

        cout << "\n\n\tContinuar? Sim(1) N�o(2)\n\n\t           ";
        cin  >> iEscolha;

        if (iEscolha == 1)
        {
        carreg();
        fasedificil();
        }
        else
        {
        system("cls");
        inicio();
        }

    }
