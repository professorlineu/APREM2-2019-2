#include <iostream>
#include <locale.h>
#include <cstdlib>
#include <windows.h>
#include <conio.h>
#include <time.h>
#include "inicio.h"
#include "carreg.h"

using namespace std;

int main()
{
    int i=0;
    int iPontuacaoS=0;


    setlocale (LC_ALL,"");
    system ("color 1F");

    Sleep(2000);

    cout << "\n\n\t";

    cout << "S";
    Sleep(100);

    cout << "e";
    Sleep(100);

    cout << "j";
    Sleep(100);

    cout << "a";
    Sleep(50);

    cout << " ";
    Sleep(100);

    cout << "B";
    Sleep(100);

    cout << "e";
    Sleep(100);

    cout << "m";
    Sleep(50);

    cout << " ";
    Sleep(100);

    cout << "V";
    Sleep(100);

    cout << "i";
    Sleep(100);

    cout << "n";
    Sleep(100);

    cout << "d";
    Sleep(100);

    cout << "o";
    Sleep(50);

    cout << " ";
    Sleep(100);

    cout << "a";
    Sleep(100);

    cout << "o";
    Sleep(100);

    cout << "\n\n\t-";

    for (i=0; i<4; i++)
    {
    cout << "----";
    Sleep(50);
    }

    cout << "\n\t|               |";
    Sleep(50);

    cout << "\n\t|  B";
    Sleep(50);

    cout << "RA";
    Sleep(50);

    cout << "IN";
    Sleep(50);

    cout << "S";
    Sleep(50);

    cout << "T";
    Sleep(50);

    cout << "O";
    Sleep(50);

    cout << "RM";
    Sleep(50);

    cout << "! ";
    Sleep(50);

    cout << " |";
    Sleep(50);

    cout << "\n\t|               |\n\t-";
    Sleep(50);


    for (i=0; i<4; i++)
    {
    cout << "----";
    Sleep(50);
    }

    Sleep(2000);

    system("cls");

    carreg();

    inicio();

}

