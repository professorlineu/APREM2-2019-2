#include <iostream>
using namespace std;

// prot�tipo da fun��o
int NIVEL1fase2 (void);
